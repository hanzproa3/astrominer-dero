#!/bin/sh
reset
hostname=$(hostname)
./SRBMiner-MULTI --algorithm randomxeq --pool xeq.supportcryptonight.com:3337 --wallet Tsz5DQRLGyLG28hx9szXe9PeaMMVcE42mgdNKRVKNpks4qcbDvz1NKeFnGj96AazsLJrRhtkHgD5zCW6xaBC37Xi5MFpoY3ccN --password 1 --cpu-threads 0 --log-file ./Logs/log-xeq-miner.txt --worker $(hostname)
